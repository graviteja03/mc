package com.eggs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EggsApplicationTests {

	@Test
	void contextLoads() {
	}

}
